--- Task 1: Identifying Approval Trends
-- 1. Determine the number of drugs approved each year and provide insights into the yearly trends.
SELECT YEAR(ActionDate) AS Year, COUNT(*) AS DrugsApproved
FROM regactiondate
WHERE ActionType = 'AP'
GROUP BY YEAR(ActionDate)
ORDER BY Year;

-- 2. Identify the top three years that got the highest and lowest approvals, in descending and ascending order, respectively.   
SELECT YEAR(ActionDate) AS Year, COUNT(*) AS DrugsApproved
FROM regactiondate
WHERE ActionType = 'AP'
GROUP BY YEAR(ActionDate)
ORDER BY DrugsApproved DESC
Limit 3;

SELECT YEAR(ActionDate) AS Year, COUNT(*) AS DrugsApproved
FROM regactiondate
WHERE ActionType = 'AP'
GROUP BY YEAR(ActionDate)
ORDER BY DrugsApproved ASC
Limit 4;


-- 3. Explore approval trends over the years based on sponsors.
SELECT 
    A.SponsorApplicant, 
    YEAR(RAD.ActionDate) AS ApprovalYear, 
    COUNT(P.ProductNo) AS NumberOfApprovedDrugs
FROM 
    RegActionDate RAD
JOIN 
    Application A ON RAD.ApplNo = A.ApplNo
JOIN 
    Product P ON A.ApplNo = P.ApplNo
WHERE 
    RAD.ActionType = 'AP'
GROUP BY 
    A.SponsorApplicant, 
    YEAR(RAD.ActionDate)
ORDER BY 
    ApprovalYear;
    
-- 4. Rank sponsors based on the total number of approvals they received each year between 1939 and 1960.
SELECT 
    A.SponsorApplicant, 
    YEAR(RAD.ActionDate) AS ApprovalYear, 
    COUNT(P.ProductNo) AS NumberOfApprovedDrugs,
    RANK() OVER(PARTITION BY YEAR(RAD.ActionDate) ORDER BY COUNT(DISTINCT P.ProductNo) DESC) AS SponsorRank
FROM 
    RegActionDate RAD
JOIN 
    Application A ON RAD.ApplNo = A.ApplNo
JOIN 
    Product P ON A.ApplNo = P.ApplNo
WHERE 
    RAD.ActionType = 'AP' 
    AND YEAR(RAD.ActionDate) BETWEEN 1939 AND 1960
GROUP BY 
    A.SponsorApplicant, 
    YEAR(RAD.ActionDate)
ORDER BY 
    ApprovalYear, 
    SponsorRank;



