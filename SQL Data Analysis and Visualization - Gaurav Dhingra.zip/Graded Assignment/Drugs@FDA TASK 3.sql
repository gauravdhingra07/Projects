--- Task 3: Analyzing Products
-- 1. Categorize Products by dosage form and analyze their distribution.
SELECT 
    YEAR(R.ActionDate) AS ApprovalYear,
    P.Form AS DosageForm, 
    COUNT( P.ProductNo) AS NumberOfProducts,
    COUNT( A.ApplNo) AS NumberOfApplications
FROM 
    Product P
JOIN 
    Application A ON P.ApplNo = A.ApplNo
JOIN 
    RegActionDate R ON A.ApplNo = R.ApplNo
GROUP BY 
    YEAR(R.ActionDate), P.Form
ORDER BY 
    ApprovalYear, NumberOfProducts DESC;

-- 2. Calculate the total number of approvals for each dosage form and identify the most successful forms.
SELECT 
    p.Form AS DosageForm, 
    COUNT(r.ActionDate) AS TotalApprovals
FROM 
    Product p
JOIN 
    RegActionDate r ON p.ApplNo = r.ApplNo
WHERE 
    r.ActionType = 'AP'
GROUP BY 
    p.Form
ORDER BY 
    TotalApprovals DESC;


-- 3. Investigate yearly trends related to successful forms. 
SELECT 
    p.Form AS DosageForm, 
    YEAR(r.ActionDate) AS ApprovalYear,
    COUNT(r.ActionDate) AS TotalApprovals
FROM 
    Product p
JOIN 
    RegActionDate r ON p.ApplNo = r.ApplNo
WHERE 
    r.ActionType = 'AP'
GROUP BY 
    p.Form, 
    YEAR(r.ActionDate)
ORDER BY 
    p.Form ASC,
    ApprovalYear DESC;



