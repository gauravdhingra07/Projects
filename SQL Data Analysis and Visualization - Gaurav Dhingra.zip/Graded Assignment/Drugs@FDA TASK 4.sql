--- Task 4: Exploring Therapeutic Classes and Approval Trends
-- 1. Analyze drug approvals based on the therapeutic evaluation code (TE_Code).
SELECT 
    PTE.TECode AS TherapeuticEvaluationCode, 
    COUNT(P.ProductNo) AS NumberOfApprovedProducts
FROM 
    Product_TECode PTE
JOIN 
    Product P ON PTE.ApplNo = P.ApplNo AND PTE.ProductNo = P.ProductNo
JOIN 
    RegActionDate RAD ON P.ApplNo = RAD.ApplNo
WHERE 
    RAD.ActionType = 'AP'
GROUP BY 
    PTE.TECode
ORDER BY 
    NumberOfApprovedProducts DESC;



-- 2. Determine the therapeutic evaluation code (TE_Code) with the highest number of Approvals in each year.
SELECT 
    PTE.TECode AS TherapeuticEvaluationCode, 
    YEAR(RAD.ActionDate) AS ApprovalYear,
    COUNT(P.ProductNo) AS NumberOfApprovedProducts
FROM 
    Product_TECode PTE
JOIN 
    Product P ON PTE.ApplNo = P.ApplNo AND PTE.ProductNo = P.ProductNo
JOIN 
    RegActionDate RAD ON P.ApplNo = RAD.ApplNo
WHERE 
    RAD.ActionType = 'AP'
GROUP BY 
    PTE.TECode, 
    YEAR(RAD.ActionDate)
ORDER BY 
    NumberOfApprovedProducts DESC;


