--- Task 2: Segmentation Analysis Based on Drug MarketingStatus

-- 1. Group products based on MarketingStatus. Provide meaningful insights into the segmentation patterns.
SELECT 
    ProductMktStatus, 
    COUNT(*) AS ProductCount,
    COUNT(DISTINCT ProductNo) AS DistinctProductCount
FROM 
    Product
GROUP BY 
    ProductMktStatus;


-- 2. Calculate the total number of applications for each MarketingStatus year-wise after the year 2010. 
SELECT 
    YEAR(RAD.ActionDate) AS Year, 
    P.ProductMktStatus, 
    COUNT(A.ApplNo) AS NumberOfApplications
FROM 
    RegActionDate RAD
JOIN 
    Application A ON RAD.ApplNo = A.ApplNo
JOIN 
    Product P ON A.ApplNo = P.ApplNo
WHERE 
    YEAR(RAD.ActionDate) > 2010
GROUP BY 
    YEAR(RAD.ActionDate), 
    P.ProductMktStatus
ORDER BY 
    Year,
    P.ProductMktStatus,
    NumberOfApplications DESC;




-- 3. Identify the top MarketingStatus with the maximum number of applications and analyze its trend over time.
SELECT 
    P.ProductMktStatus, 
    COUNT(A.ApplNo) AS NumberOfApplications
FROM 
    Product P
JOIN 
    Application A ON P.ApplNo = A.ApplNo
GROUP BY 
    P.ProductMktStatus
ORDER BY 
    NumberOfApplications DESC
LIMIT 4;
    
-- Over the years anaysis
SELECT 
    YEAR(RAD.ActionDate) AS Year, 
    P.ProductMktStatus, 
    COUNT(A.ApplNo) AS NumberOfApplications
FROM 
    Product P
JOIN 
    Application A ON P.ApplNo = A.ApplNo
JOIN 
    RegActionDate RAD ON A.ApplNo = RAD.ApplNo
GROUP BY 
    YEAR(RAD.ActionDate), 
    P.ProductMktStatus
ORDER BY 
    Year, 
    P.ProductMktStatus,
    NumberOfApplications DESC;

